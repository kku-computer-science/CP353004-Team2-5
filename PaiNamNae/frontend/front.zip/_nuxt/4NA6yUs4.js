import{ac as e,C as t}from"./BQkvMFwM.js";import{u as a}from"./oF58fMAn.js";const u=e(o=>{if(!a("token").value&&o.path!=="/login")return t("/login")});export{u as default};
